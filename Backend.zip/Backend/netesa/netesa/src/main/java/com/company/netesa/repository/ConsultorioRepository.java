package com.company.netesa.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.company.netesa.model.Consultorio;

public interface ConsultorioRepository extends JpaRepository<Consultorio, Long> {

}
